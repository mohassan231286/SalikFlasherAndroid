package com.salikflasher;

import android.app.Activity;
import android.content.Intent;
import android.hardware.usb.*;
import android.os.Bundle;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    UsbManager usbManager;
    UsbDeviceConnection connection;
    UsbSerialBridge serialBridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usbManager = (UsbManager) getSystemService(USB_SERVICE);
        webView = findViewById(R.id.webview);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        serialBridge = new UsbSerialBridge(this, usbManager, webView);
        webView.addJavascriptInterface(serialBridge, "UsbBridge");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());

        webView.loadData(getHtmlApp(), "text/html", "UTF-8");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
            UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            if (device != null) {
                serialBridge.onDeviceAttached(device);
            }
        }
    }

    private String getHtmlApp() {
        return "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>" +
        "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<title>Salik Flasher</title><style>" +
        "*{box-sizing:border-box;margin:0;padding:0}" +
        "body{background:#0f1117;color:#e2e8f0;font-family:system-ui,sans-serif;font-size:14px}" +
        ".header{background:#1a1d27;padding:14px 16px;border-bottom:1px solid #2e3350;display:flex;align-items:center;gap:10px}" +
        ".header h1{font-size:16px;color:#4f8ef7}" +
        ".dot{width:10px;height:10px;border-radius:50%;background:#8892a4}" +
        ".dot.on{background:#22c55e}" +
        ".tabs{display:flex;background:#1a1d27;border-bottom:1px solid #2e3350;overflow-x:auto}" +
        ".tab{padding:12px 16px;font-size:12px;font-weight:600;color:#8892a4;cursor:pointer;white-space:nowrap;border-bottom:2px solid transparent}" +
        ".tab.active{color:#4f8ef7;border-bottom-color:#4f8ef7}" +
        ".page{display:none;padding:16px}" +
        ".page.active{display:block}" +
        ".card{background:#1a1d27;border:1px solid #2e3350;border-radius:12px;padding:14px;margin-bottom:12px}" +
        ".card-title{font-size:11px;color:#8892a4;font-weight:700;text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px}" +
        ".btn{display:inline-flex;align-items:center;justify-content:center;padding:10px 18px;border-radius:8px;font-size:13px;font-weight:700;border:none;cursor:pointer;width:100%;margin-bottom:8px}" +
        ".btn-blue{background:#4f8ef7;color:#fff}" +
        ".btn-green{background:#22c55e;color:#fff}" +
        ".btn-red{background:rgba(239,68,68,.15);color:#ef4444;border:1px solid rgba(239,68,68,.3)}" +
        ".btn-ghost{background:#22263a;color:#e2e8f0;border:1px solid #2e3350}" +
        ".stat-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}" +
        ".stat{background:#22263a;border-radius:10px;padding:12px}" +
        ".stat-label{font-size:10px;color:#8892a4;margin-bottom:4px}" +
        ".stat-val{font-size:18px;font-weight:700}" +
        ".progress-wrap{height:8px;background:#22263a;border-radius:4px;margin:8px 0;overflow:hidden}" +
        ".progress-fill{height:100%;background:#4f8ef7;border-radius:4px;transition:width .3s}" +
        ".log{background:#0a0d14;border-radius:8px;padding:10px;height:180px;overflow-y:auto;font-family:monospace;font-size:11px}" +
        ".log-line{padding:1px 0}" +
        ".seg-bar{height:32px;border-radius:6px;overflow:hidden;display:flex;margin-bottom:10px}" +
        ".seg-piece{display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;overflow:hidden}" +
        ".dev-item{background:#22263a;border-radius:8px;padding:10px 12px;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center}" +
        ".dev-name{font-weight:600;font-size:13px}" +
        ".dev-id{font-size:11px;color:#8892a4;font-family:monospace}" +
        "input,select{background:#22263a;border:1px solid #2e3350;color:#e2e8f0;border-radius:8px;padding:8px 10px;font-size:12px;width:100%;margin-bottom:8px}" +
        ".steps{display:flex;justify-content:space-between;margin-bottom:14px}" +
        ".step{display:flex;flex-direction:column;align-items:center;flex:1}" +
        ".step-dot{width:24px;height:24px;border-radius:50%;background:#22263a;border:1.5px solid #2e3350;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;margin-bottom:3px}" +
        ".step-dot.done{background:#22c55e;border-color:#22c55e}" +
        ".step-dot.active{background:#4f8ef7;border-color:#4f8ef7}" +
        ".step-label{font-size:9px;color:#8892a4;text-align:center}" +
        "input[type=file]{display:none}" +
        ".file-pick{border:2px dashed #2e3350;border-radius:10px;padding:20px;text-align:center;cursor:pointer;margin-bottom:10px}" +
        ".file-pick:hover{border-color:#4f8ef7}" +
        "</style></head><body>" +

        "<div class='header'>" +
        "<div class='dot' id='conn-dot'></div>" +
        "<h1>⚡ Salik Flasher — GX6605S</h1>" +
        "</div>" +

        "<div class='tabs'>" +
        "<div class='tab active' onclick='showTab(0)'>🏠 الرئيسية</div>" +
        "<div class='tab' onclick='showTab(1)'>⚡ فلاش</div>" +
        "<div class='tab' onclick='showTab(2)'>⚙️ Config</div>" +
        "<div class='tab' onclick='showTab(3)'>🖥️ طرفية</div>" +
        "</div>" +

        // ── صفحة الرئيسية ──
        "<div class='page active' id='p0'>" +
        "<div class='stat-grid'>" +
        "<div class='stat'><div class='stat-label'>الحالة</div><div class='stat-val' id='stat-conn' style='font-size:13px;color:#8892a4'>غير متصل</div></div>" +
        "<div class='stat'><div class='stat-label'>المعالج</div><div class='stat-val' style='font-size:14px;color:#4f8ef7'>GX6605S</div></div>" +
        "</div>" +
        "<div class='card'><div class='card-title'>أجهزة USB</div><div id='dev-list'><p style='color:#8892a4;text-align:center;padding:16px'>لا توجد أجهزة — وصّل كابل OTG</p></div></div>" +
        "<button class='btn btn-ghost' onclick='scanDevices()'>🔄 فحص الأجهزة</button>" +
        "<button class='btn btn-red' id='btn-disc' style='display:none' onclick='disconnect()'>قطع الاتصال</button>" +
        "<div class='card'><div class='card-title'>سجل الأحداث</div><div class='log' id='log0'></div></div>" +
        "</div>" +

        // ── صفحة الفلاش ──
        "<div class='page' id='p1'>" +
        "<div class='steps'>" +
        "<div class='step'><div class='step-dot' id='sd0'>1</div><div class='step-label'>ملف</div></div>" +
        "<div class='step'><div class='step-dot' id='sd1'>2</div><div class='step-label'>مسح</div></div>" +
        "<div class='step'><div class='step-dot' id='sd2'>3</div><div class='step-label'>كتابة</div></div>" +
        "<div class='step'><div class='step-dot' id='sd3'>4</div><div class='step-label'>تحقق</div></div>" +
        "<div class='step'><div class='step-dot' id='sd4'>5</div><div class='step-label'>تم</div></div>" +
        "</div>" +
        "<div class='progress-wrap'><div class='progress-fill' id='prog' style='width:0%'></div></div>" +
        "<p id='prog-txt' style='color:#8892a4;font-size:12px;text-align:right;margin-bottom:10px'>0%</p>" +
        "<div class='file-pick' onclick='document.getElementById(\"file-in\").click()'>" +
        "<input type='file' id='file-in' accept='.bin,.boot,.img' onchange='onFileSelect(this)'>" +
        "<div id='file-info'><p style='font-size:24px'>📂</p><p style='color:#e2e8f0;font-weight:700'>اختر ملف الفيرموير</p><p style='color:#8892a4;font-size:12px'>.bin .boot .img</p></div>" +
        "</div>" +
        "<div class='card'><div class='card-title'>عنوان البداية</div>" +
        "<select id='start-addr'>" +
        "<option value='0x00000000'>0x00000000 — Bootload</option>" +
        "<option value='0x00010000' selected>0x00010000 — Main Code</option>" +
        "<option value='0x00130000'>0x00130000 — Logo</option>" +
        "</select></div>" +
        "<button class='btn btn-blue' onclick='startFlash()'>⚡ بدء الفلاش</button>" +
        "<div class='card'><div class='card-title'>السجل</div><div class='log' id='flash-log'></div></div>" +
        "</div>" +

        // ── صفحة Config ──
        "<div class='page' id='p2'>" +
        "<div class='card'><div class='card-title'>🗺️ خريطة Flash Memory — 8MB</div>" +
        "<div class='seg-bar' id='seg-bar'>" +
        "<div class='seg-piece' style='flex:1;background:#4f8ef7'>Bootload</div>" +
        "<div class='seg-piece' style='flex:18;background:#7c3aed'>Main Code</div>" +
        "<div class='seg-piece' style='flex:1;background:#22c55e'>Logo</div>" +
        "<div class='seg-piece' style='flex:8;background:#f59e0b'>UsrDB</div>" +
        "<div class='seg-piece' style='flex:4;background:#14b8a6'>SysDB</div>" +
        "<div class='seg-piece' style='flex:4;background:#ec4899'>Key</div>" +
        "</div></div>" +
        "<div class='card'><div class='card-title'>أقسام الذاكرة</div>" +
        "<table style='width:100%;font-size:12px;border-collapse:collapse'>" +
        "<tr style='color:#8892a4'><td style='padding:4px'>القسم</td><td>البداية</td><td>الحجم</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>Bootload</td><td style='font-family:monospace;color:#4f8ef7'>0x00000000</td><td style='color:#8892a4'>64 KB</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>Main Code</td><td style='font-family:monospace;color:#4f8ef7'>0x00010000</td><td style='color:#8892a4'>1152 KB</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>Logo</td><td style='font-family:monospace;color:#4f8ef7'>0x00130000</td><td style='color:#8892a4'>32 KB</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>UsrDB</td><td style='font-family:monospace;color:#4f8ef7'>0x00140000</td><td style='color:#8892a4'>512 KB</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>SysDB</td><td style='font-family:monospace;color:#4f8ef7'>0x001C0000</td><td style='color:#8892a4'>128 KB</td></tr>" +
        "<tr style='border-top:1px solid #2e3350'><td style='padding:6px 4px'>Key</td><td style='font-family:monospace;color:#4f8ef7'>0x001E0000</td><td style='color:#8892a4'>128 KB</td></tr>" +
        "</table></div>" +
        "</div>" +

        // ── صفحة الطرفية ──
        "<div class='page' id='p3'>" +
        "<div class='card'><div class='card-title'>أوامر سريعة</div>" +
        "<div style='display:flex;gap:6px;flex-wrap:wrap'>" +
        "<button class='btn btn-ghost' style='width:auto;padding:6px 12px' onclick='sendHex(\"55\")'>Handshake</button>" +
        "<button class='btn btn-ghost' style='width:auto;padding:6px 12px' onclick='sendHex(\"55 AA 01 00 00 56\")'>Get Info</button>" +
        "<button class='btn btn-ghost' style='width:auto;padding:6px 12px' onclick='sendHex(\"55 AA 06 00 00 5B\")'>Reboot</button>" +
        "</div></div>" +
        "<div class='log' id='term-log' style='height:240px;margin-bottom:10px'></div>" +
        "<div style='display:flex;gap:8px'>" +
        "<input type='text' id='term-in' placeholder='55 AA ...' style='font-family:monospace;flex:1;margin:0'>" +
        "<button class='btn btn-blue' style='width:auto;padding:8px 16px;margin:0' onclick='sendTermCmd()'>إرسال</button>" +
        "</div></div>" +

        "<script>" +
        "var curTab=0,flashing=false,selFile=null;" +
        "function showTab(n){" +
        "document.querySelectorAll('.page').forEach((p,i)=>p.classList.toggle('active',i===n));" +
        "document.querySelectorAll('.tab').forEach((t,i)=>t.classList.toggle('active',i===n));" +
        "curTab=n;}" +

        "function log(msg,color,logId){" +
        "var el=document.getElementById(logId||'log0');" +
        "var d=document.createElement('div');" +
        "d.className='log-line';d.style.color=color||'#8892a4';" +
        "d.textContent=msg;el.appendChild(d);el.scrollTop=el.scrollHeight;}" +

        "function scanDevices(){" +
        "log('فحص أجهزة USB...','#4f8ef7');" +
        "var r=UsbBridge.getDevices();" +
        "var devs=JSON.parse(r);" +
        "var el=document.getElementById('dev-list');" +
        "if(devs.length===0){el.innerHTML='<p style=\"color:#8892a4;text-align:center;padding:16px\">لا توجد أجهزة</p>';return;}" +
        "el.innerHTML='';" +
        "devs.forEach(function(d){" +
        "var div=document.createElement('div');div.className='dev-item';" +
        "div.innerHTML='<div><div class=\"dev-name\">'+d.name+'</div><div class=\"dev-id\">VID:'+d.vid+' PID:'+d.pid+'</div></div>'+" +
        "'<button class=\"btn btn-blue\" style=\"width:auto;padding:6px 12px\" onclick=\"connectDevice('+d.id+')\">اتصال</button>';" +
        "el.appendChild(div);});}" +

        "function connectDevice(id){" +
        "log('جاري الاتصال...','#f59e0b');" +
        "var ok=UsbBridge.connect(id);" +
        "if(ok){" +
        "document.getElementById('conn-dot').classList.add('on');" +
        "document.getElementById('stat-conn').textContent='متصل ✓';" +
        "document.getElementById('stat-conn').style.color='#22c55e';" +
        "document.getElementById('btn-disc').style.display='block';" +
        "log('تم الاتصال بنجاح ✓','#22c55e');" +
        "}else{log('فشل الاتصال','#ef4444');}}" +

        "function disconnect(){" +
        "UsbBridge.disconnect();" +
        "document.getElementById('conn-dot').classList.remove('on');" +
        "document.getElementById('stat-conn').textContent='غير متصل';" +
        "document.getElementById('stat-conn').style.color='#8892a4';" +
        "document.getElementById('btn-disc').style.display='none';" +
        "log('تم قطع الاتصال','#8892a4');}" +

        "function onFileSelect(input){" +
        "if(input.files.length===0)return;" +
        "selFile=input.files[0];" +
        "document.getElementById('file-info').innerHTML='<p style=\"font-weight:700\">📄 '+selFile.name+'</p><p style=\"color:#8892a4;font-size:12px\">'+(selFile.size/1024).toFixed(1)+' KB</p>';" +
        "log('تم اختيار: '+selFile.name,'#22c55e','flash-log');}" +

        "function setStep(n){" +
        "for(var i=0;i<5;i++){" +
        "var d=document.getElementById('sd'+i);" +
        "d.className='step-dot'+(i<n?' done':i===n?' active':'');}}" +

        "function setProg(p){" +
        "document.getElementById('prog').style.width=p+'%';" +
        "document.getElementById('prog-txt').textContent=p+'%';}" +

        "function startFlash(){" +
        "if(!selFile){alert('اختر ملف الفيرموير أولاً');return;}" +
        "if(!UsbBridge.isConnected()){alert('اتصل بالرسيفر أولاً');return;}" +
        "if(flashing)return;" +
        "if(!confirm('سيتم مسح وكتابة الذاكرة. هل أنت متأكد؟'))return;" +
        "flashing=true;" +
        "var addr=document.getElementById('start-addr').value;" +
        "var reader=new FileReader();" +
        "reader.onload=function(e){" +
        "var b64=btoa(String.fromCharCode.apply(null,new Uint8Array(e.target.result)));" +
        "UsbBridge.flashFirmware(addr,b64);};" +
        "reader.readAsArrayBuffer(selFile);}" +

        "function onFlashProgress(pct,step,msg){" +
        "setProg(pct);setStep(step);" +
        "log(msg,pct===100?'#22c55e':pct<0?'#ef4444':'#4f8ef7','flash-log');" +
        "if(pct>=100||pct<0)flashing=false;}" +

        "function sendHex(hex){" +
        "if(!UsbBridge.isConnected()){log('غير متصل','#ef4444','term-log');return;}" +
        "var r=UsbBridge.sendHex(hex);" +
        "log('→ '+hex.toUpperCase(),'#4f8ef7','term-log');" +
        "if(r)log('← '+r,'#22c55e','term-log');}" +

        "function sendTermCmd(){" +
        "var v=document.getElementById('term-in').value.trim();" +
        "if(!v)return;sendHex(v);document.getElementById('term-in').value='';}" +

        "function onUsbData(hex){log('← '+hex,'#22c55e','term-log');}" +
        "function onDeviceAttached(name){log('✓ جهاز متصل: '+name,'#22c55e');scanDevices();}" +

        "scanDevices();" +
        "</script></body></html>";
    }
}
