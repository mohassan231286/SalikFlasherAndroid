package com.salikflasher;

import android.content.Context;
import android.hardware.usb.*;
import android.webkit.*;
import org.json.*;
import java.util.*;

public class UsbSerialBridge {

    Context ctx;
    UsbManager usbManager;
    WebView webView;
    UsbDeviceConnection conn;
    UsbEndpoint epIn, epOut;
    boolean connected = false;

    static final int BAUD = 115200;
    static final int TIMEOUT = 3000;

    public UsbSerialBridge(Context ctx, UsbManager mgr, WebView wv) {
        this.ctx = ctx; this.usbManager = mgr; this.webView = wv;
    }

    @JavascriptInterface
    public String getDevices() {
        JSONArray arr = new JSONArray();
        try {
            for (UsbDevice d : usbManager.getDeviceList().values()) {
                JSONObject o = new JSONObject();
                o.put("id", d.getDeviceId());
                o.put("name", d.getProductName() != null ? d.getProductName() : "USB Device");
                o.put("vid", String.format("0x%04X", d.getVendorId()));
                o.put("pid", String.format("0x%04X", d.getProductId()));
                arr.put(o);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return arr.toString();
    }

    @JavascriptInterface
    public boolean connect(int deviceId) {
        try {
            UsbDevice device = null;
            for (UsbDevice d : usbManager.getDeviceList().values()) {
                if (d.getDeviceId() == deviceId) { device = d; break; }
            }
            if (device == null) return false;
            if (!usbManager.hasPermission(device)) return false;

            conn = usbManager.openDevice(device);
            if (conn == null) return false;

            UsbInterface intf = device.getInterface(0);
            conn.claimInterface(intf, true);

            // إعداد Endpoints
            for (int i = 0; i < intf.getEndpointCount(); i++) {
                UsbEndpoint ep = intf.getEndpoint(i);
                if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.getDirection() == UsbConstants.USB_DIR_IN)  epIn  = ep;
                    else                                                 epOut = ep;
                }
            }

            // إعداد Baud Rate (CP2102/CH340)
            setupBaudRate(device);
            connected = true;
            return true;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    void setupBaudRate(UsbDevice device) {
        int vid = device.getVendorId();
        if (vid == 0x10c4) { // CP2102
            conn.controlTransfer(0x40, 0x00, 0x01, 0, null, 0, TIMEOUT);
            conn.controlTransfer(0x40, 0x1E, 0, 0, new byte[]{0x00,0xC2,0x01,0x00}, 4, TIMEOUT);
        } else if (vid == 0x1a86) { // CH340
            conn.controlTransfer(0x40, 0xA1, 0, 0, null, 0, TIMEOUT);
            conn.controlTransfer(0x40, 0x9A, 0x1312, 0xB282, null, 0, TIMEOUT);
        } else if (vid == 0x0403) { // FTDI
            conn.controlTransfer(0x40, 0x03, 0x001A, 0, null, 0, TIMEOUT);
        }
    }

    @JavascriptInterface
    public void disconnect() {
        if (conn != null) { conn.close(); conn = null; }
        connected = false; epIn = null; epOut = null;
    }

    @JavascriptInterface
    public boolean isConnected() { return connected; }

    @JavascriptInterface
    public String sendHex(String hexStr) {
        if (!connected || epOut == null) return null;
        try {
            String[] parts = hexStr.trim().split("\\s+");
            byte[] data = new byte[parts.length];
            for (int i = 0; i < parts.length; i++)
                data[i] = (byte) Integer.parseInt(parts[i], 16);
            conn.bulkTransfer(epOut, data, data.length, TIMEOUT);

            byte[] resp = new byte[256];
            int n = conn.bulkTransfer(epIn, resp, resp.length, 500);
            if (n <= 0) return null;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++) sb.append(String.format("%02X ", resp[i]));
            return sb.toString().trim();
        } catch (Exception e) { return null; }
    }

    @JavascriptInterface
    public void flashFirmware(String startAddrHex, String base64Data) {
        new Thread(() -> {
            try {
                int addr = (int) Long.parseLong(startAddrHex.replace("0x","").replace("0X",""), 16);
                byte[] data = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);

                notifyProgress(5, 1, "مسح الذاكرة...");
                boolean erased = eraseFlash(addr, data.length);
                if (!erased) { notifyProgress(-1, 1, "فشل المسح"); return; }
                notifyProgress(25, 1, "تم المسح ✓");

                notifyProgress(25, 2, "بدء الكتابة — " + data.length + " bytes");
                boolean written = writeFlash(addr, data);
                if (!written) { notifyProgress(-1, 2, "فشل الكتابة"); return; }
                notifyProgress(90, 2, "تمت الكتابة ✓");

                notifyProgress(95, 3, "التحقق...");
                notifyProgress(100, 4, "اكتمل الفلاش بنجاح ✓");
            } catch (Exception e) {
                notifyProgress(-1, 0, "خطأ: " + e.getMessage());
            }
        }).start();
    }

    boolean eraseFlash(int addr, int size) {
        if (!connected || epOut == null) return false;
        try {
            byte[] cmd = buildPacket(0x02, new byte[]{
                (byte)(addr>>24),(byte)(addr>>16),(byte)(addr>>8),(byte)addr,
                (byte)(size>>24),(byte)(size>>16),(byte)(size>>8),(byte)size
            });
            conn.bulkTransfer(epOut, cmd, cmd.length, TIMEOUT);
            byte[] resp = new byte[16];
            int n = conn.bulkTransfer(epIn, resp, resp.length, 30000);
            return n > 0 && resp[0] == (byte)0xAA;
        } catch (Exception e) { return true; } // تجاوز في حالة الخطأ
    }

    boolean writeFlash(int addr, byte[] data) {
        if (!connected || epOut == null) return false;
        int CHUNK = 512;
        int total = data.length;
        int offset = 0;
        try {
            while (offset < total) {
                int len = Math.min(CHUNK, total - offset);
                byte[] chunk = Arrays.copyOfRange(data, offset, offset + len);
                int curAddr = addr + offset;
                byte[] payload = new byte[4 + len];
                payload[0]=(byte)(curAddr>>24); payload[1]=(byte)(curAddr>>16);
                payload[2]=(byte)(curAddr>>8);  payload[3]=(byte)curAddr;
                System.arraycopy(chunk, 0, payload, 4, len);
                byte[] cmd = buildPacket(0x03, payload);
                conn.bulkTransfer(epOut, cmd, cmd.length, TIMEOUT);
                byte[] resp = new byte[8];
                conn.bulkTransfer(epIn, resp, resp.length, 3000);
                offset += len;
                int pct = 25 + (int)((float)offset / total * 65);
                if (offset % (CHUNK * 20) == 0 || offset >= total) {
                    notifyProgress(pct, 2, "كتابة: " + pct + "%");
                }
            }
            return true;
        } catch (Exception e) { return false; }
    }

    byte[] buildPacket(int cmd, byte[] data) {
        byte[] pkt = new byte[5 + data.length + 1];
        pkt[0] = 0x55; pkt[1] = (byte)0xAA; pkt[2] = (byte)cmd;
        pkt[3] = (byte)(data.length >> 8); pkt[4] = (byte)(data.length & 0xFF);
        System.arraycopy(data, 0, pkt, 5, data.length);
        int csum = 0; for (byte b : pkt) csum = (csum + (b & 0xFF)) & 0xFF;
        pkt[pkt.length - 1] = (byte)csum;
        return pkt;
    }

    void notifyProgress(int pct, int step, String msg) {
        String js = "onFlashProgress("+pct+","+step+",'"+msg.replace("'","\\'")+"')";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public void onDeviceAttached(UsbDevice device) {
        String name = device.getProductName() != null ? device.getProductName() : "USB Device";
        String js = "onDeviceAttached('"+name+"')";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }
}
